Name: Dolton M. Fernandes
Roll No: 2018111007 (CSD)

Qn1:

1) Compile Qn1.c using : gcc Qn1.c
2) Run the program using the command : ./a.out "input file location"

Qn2:

1) Compile Qn2.c using : gcc Qn2.c
2) Run the program using the command : ./a.out "new file location" "old file location" "Directory location"
