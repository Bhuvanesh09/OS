#include"header.h"

void handler1(int sig_num){}

void handler2(int sig_num){}