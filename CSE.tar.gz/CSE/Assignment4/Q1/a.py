from random import randint
N = 1000
print(N)
for i in range(N):
	print(randint(1,1000000000),end=" ")
print()